# math-proof siege: a First Proof Batch 3 submission

_Research artifact. Not maintained and not accepting contributions._

## Approach

Each problem is given, once, to `/math-proof:siege`, a skill from the public [`math-proof`
plugin](https://github.com/anthropics/claude-plugins-official/tree/main/plugins/math-proof) for
[Claude Code](https://code.claude.com/docs), Anthropic's command-line agent. The plugin is used
unmodified (`vendor/math-proof`, see [vendor/README.md](vendor/README.md)). Everything else in this
repository is a thin runner around it: it starts one session per problem, decides whether the result
is fit to hand in, has it typeset in LaTeX, and keeps the logs.

**What the skill does.** The main session does no mathematics. It runs up to fourteen rounds of
sub-agents, each starting fresh. In each round a *judge* writes a few self-contained questions,
independent *workers* answer them in parallel, and the judge keeps a ledger of what is proved,
refuted and open. When a worker's answer contains a complete proof of the goal, two more workers
check that exact text line by line before the judge may conclude. If the opening rounds do not get
there, later rounds send up to ten workers at the one statement the proof still lacks. At the end
the judge writes a self-contained `proof.md` whose "Status" section says plainly what is and is not
proved. The full instructions are in
[vendor/math-proof/skills/siege/SKILL.md](vendor/math-proof/skills/siege/SKILL.md).

![How a siege run unfolds](vendor/math-proof/assets/how-a-run-unfolds.png)

**Model.** The runner asks for `claude-opus-5-5` (Claude Opus 5.5) through the Anthropic API for
every session, and sub-agents inherit it. `by_model` in `token_usage_summary.json` shows which model
answered each request.

**Web tools are off.** The rules allow web access, but the skill switches Claude Code's web search
and fetch tools off for its run, and the sessions the runner adds do not have them either. Citations
therefore come from the model's memory, and the write-up instructions say to give only details it is
confident of. This is a matter of tool lists and instructions, not of a firewall; see "Notes for the
code review".

## What happens to one problem

All problems start at once, each in its own directory, and go through three stages
([src/run.py](src/run.py)).

1. **Solve.** `claude -p "/math-proof:siege problem.md" --model claude-opus-5-5 --effort high
   --dangerously-skip-permissions`, which is the unattended form given in the plugin's README, with
   the skill's default settings. `problem.md` holds the problem's `latex` field, verbatim.
2. **Decide.** A wrong proof scores below a blank one, so a solution is handed in only if (a) the
   skill ran to its end, (b) the closing verdict line of its last judge step reads `MAIN CLAIM:
   PROVED` and not `NOT PROVED` or some form in between, and (c) a fresh session that sees only the
   problem and `proof.md` confirms that the claim proved is the problem as posed, in full, and that
   the document reports no gap ([src/prompts/scope_check.md](src/prompts/scope_check.md)). That
   session does not re-prove or repair anything.
3. **Write up.** A fresh session turns `proof.md` (Markdown, any length) into one self-contained,
   anonymous LaTeX file of at most 16 pages without changing the mathematics
   ([src/prompts/writeup.md](src/prompts/writeup.md)). Its file is accepted only if the session
   printed its closing reply saying it had finished, and if a copy of the file, compiled by the
   runner with pdfLaTeX alone in an empty directory, gives no error, no undefined reference, at most
   16 pages, and none of a list of words that would give the author away. Last, a fresh read-only
   session compares the LaTeX with `proof.md`, statement by statement, and must find the same
   complete argument in both ([src/prompts/fidelity_check.md](src/prompts/fidelity_check.md)).
   Otherwise a new write-up session is told what failed; up to four write-ups may come out too long
   and up to three may fail another check before the runner gives up. If the writer finds a real
   error in the proof it says so, and nothing is handed in.

If any stage fails, the problem's file says "No solution is submitted for this problem." and the
material produced stays in `logs/`. The setting `FP_SUBMIT_POLICY` makes stage 2 stricter or turns
it off (see "Settings").

**One attempt per problem, no human in the loop.** The skill is invoked once per problem; the runner
never runs it twice on a problem to pick the better result. If a Claude Code session dies or stops
before the skill has finished (an API outage, a crash, a full context window), the runner waits a
little and gives the same command again in the same directory, until the solving deadline. The skill
then continues from its own state file without redoing finished steps, which is the plugin README's
instruction for a stopped run. A stage 2 or 3 session that crashes or ends in an API error is
likewise started again, for up to about 45 minutes.

## Output

Everything listed here is written to `/data/output/` as the run goes, so a timeout loses only work
in flight.

| File | Contents |
|---|---|
| `<id>.tex` | The solution, or the one-line "no solution" page. Written for every problem in the first second and replaced only by a checked solution. |
| `<id>.pdf` | The compiled solution (only where one is submitted). |
| `progress.json` | Heartbeat, rewritten every minute: `timestamp_utc`, a one-line `status`, and each problem's stage, tokens so far and, while it is being solved, the step the skill has reached. |
| `token_usage.jsonl` | One line per model response, rewritten every minute. See below. |
| `token_usage_summary.json` | Totals: overall and by problem, stage, agent type and model. |
| `results.json` | Written at the end: each problem's outcome, the reason when nothing was submitted, and the skill's own verdict. |
| `logs/<id>/work/math-proof-run/` | The skill's run folder: every question, answer, ledger, summary, `state.md`, `proof.md`. |
| `logs/<id>/writeup/` | Inputs and outputs of stages 2 and 3. |
| `logs/<id>/*.stream.jsonl`, `*.stderr.txt` | Everything each Claude Code session printed. The first holds, as JSON lines, the main session's messages, and the tool calls and tool results of the main session and its sub-agents. |

Claude Code's own configuration directory (its settings, caches and saved session transcripts) is
that program's working space, not a result. It stays inside the container, one per problem, under
`/home/solver/claude-code/`, and nothing from it is copied to `/data/output/` except what the token
log described below records.

An `<id>` is the problem's `id` made safe as a file name: characters other than letters, digits,
dot, dash and underscore become underscores, leading dots and underscores are dropped, it is cut at
80 characters, and an underscore is added if two ids would otherwise coincide. The exit code is 0
whenever the runner reaches its end, whatever the number of solutions and also after SIGTERM, and 2
for a start-up failure (see "Secrets").

### Token log

Each line of `token_usage.jsonl` is one response from the Anthropic API: time, problem, stage,
session, agent (main session, judge, worker or deep worker), model, message and request ids, stop
reason, and the API's own counts: `input_tokens`, `cache_creation_input_tokens`,
`cache_read_input_tokens`, `output_tokens` and `thinking_tokens`. **`output_tokens` includes the
hidden thinking**, and `thinking_tokens` is the part of it that was thinking, as the API reports it
in `usage.output_tokens_details`. The counts are read from the transcripts Claude Code saves for
every session and sub-agent ([src/tokens.py](src/tokens.py) explains the source and how it was
checked). The summary file also carries the totals Claude Code itself reports at the end of each
session, as a cross-check.

One limit: a response that was still streaming when its session was killed (at a deadline or a
timeout) is missing, or is listed with `stop_reason` null and the provisional counts it had when it
began. And if the container is killed outright, rather than by the SIGTERM that `timeout` sends, the
token log stands as of the last minute's rewrite and cannot be rebuilt, because the transcripts go
with the container.

## Secrets

`secrets.env` needs one line, without quotation marks:

```
ANTHROPIC_API_KEY=sk-ant-...
```

The container begins with one tiny request through Claude Code. If the key is missing, or the API
keeps refusing the request for ten minutes (HTTP 400, 401, 403 or 404: a bad key, or a model the
account may not use), or Claude Code itself does not start, the container stops with exit code 2 and
a message beginning `FATAL:` on stderr and in `progress.json`. Rate limits, overload and timeouts
are not fatal, here or later: Claude Code waits and retries, and after half an hour of that at
start-up the run goes ahead anyway.

## Time, load and hardware

- `timeout_minutes` is 1440. The runner keeps its own clock from container start: sessions still
  solving after 20 hours are stopped (their problems get no solution), and no session runs past 22.5
  hours. The container exits within about twenty minutes after that, and a backstop ends it at 23
  hours whatever happens. Each problem is typeset as soon as it is solved, without waiting for the
  others.
- Under a shorter limit that the container cannot see, such as the 30-minute pre-run check, the
  runner reacts to the SIGTERM that `timeout` sends through `docker run`: it stops all sessions,
  hands in nothing unfinished, brings the token log and `progress.json` up to date, and exits,
  normally within a minute.
- With ten hard problems, up to about a hundred model responses can be streaming at once. The API
  account needs rate limits and credit to match; lower `FP_MAX_PARALLEL` otherwise.
- No GPU. Memory is the reason for `r7i.2xlarge`: ten long-running Claude Code processes, each
  holding many conversations.
- Disk use is small. The logs in `/data/output` and Claude Code's working files inside the container
  end up on the same root volume; together they came to about 10 MB for the two example problems.

## Settings

Environment variables, all optional; the defaults are the submission. They can be added to
`secrets.env`.

| Variable | Default | Meaning |
|---|---|---|
| `FP_MODEL` | `claude-opus-5-5` | Model requested for every session; sub-agents inherit it. |
| `FP_EFFORT` | `high` | Thinking effort of the main sessions. Sub-agents keep the levels set in the plugin's agent files. |
| `FP_SUBMIT_POLICY` | `verified` | `verified`: hand in only what passed stage 2. `certified`: in addition, two separate workers must have certified the proof during the rounds (the plugin's `ledger.py gate`). `always`: no stage 2; typeset whatever `proof.md` exists, with its gaps stated in the text. |
| `FP_SIEGE_SETTINGS` | empty | Settings passed to the skill, for example `MAX_ROUNDS=10`. |
| `FP_MAX_PARALLEL` | `10` | Problems worked on at once. Further problems wait, and the solving time is divided accordingly. |
| `FP_SOLVE_HOURS`, `FP_TOTAL_HOURS` | `20`, `22.5` | The two deadlines, in hours from container start. |
| `FP_RESTART_PAUSE_SECONDS` | `60` | Wait before a dead session is continued. It doubles, up to 15 minutes, for every session in a row that lasted under five minutes or wrote nothing. |
| `FP_STALL_MINUTES` | `120` | A session under which no run file or transcript is written for this long is stopped (and, in stage 1, continued). |
| `FP_MAX_OUTPUT_TOKENS_PER_PROBLEM` | `40000000` | Guard against a runaway in stage 1; the problem is given up beyond it. |
| `FP_PAGE_ATTEMPTS`, `FP_WRITEUP_ATTEMPTS` | `4`, `3` | How many write-ups of a problem may exceed the page limit, and how many may fail any other check. |
| `FP_WRITEUP_MINUTES`, `FP_CHECK_MINUTES` | `60`, `30` | Time limit of each write-up session, and of each scope-check or comparison session. |
| `FP_PREFLIGHT_SECONDS` | `300` | Time allowed to each start-up test request. |

## Notes for the code review

- **What to read:** `Dockerfile`, `src/entrypoint.sh`, `src/run.py` (the whole pipeline),
  `src/tokens.py` (the token log), `src/prompts/` (the only prompts that are ours). Python standard
  library only. `vendor/math-proof` is the public plugin; the build checks its checksums.
- **Dependencies:** the `node:22-bookworm-slim` image; Debian packages for Python 3 (with sympy,
  mpmath, numpy, scipy, networkx for the judge's numeric checks), TeX Live, poppler-utils,
  ca-certificates, git, procps and tini; and `@anthropic-ai/claude-code@2.1.282` from npm. Claude
  Code is publicly available but is not open source; the runner and the plugin are Apache-2.0.
- **Model-written code runs inside the container.** The skill's judge may run short Python checks
  and file operations through Claude Code's shell tool, and the write-up session runs pdfLaTeX.
  Sessions are started with `--dangerously-skip-permissions`, as in the plugin's unattended form.
  No session and no model-written code runs as root: the entry point creates an ordinary user and
  drops to it before it starts the runner. Within that limit nothing technically confines such code.
  It has the container's open outbound network, it can see `ANTHROPIC_API_KEY` in its environment,
  and it can write anywhere under `/data/output`. The instructions tell the sessions to use the
  shell only for checks and file handling and not to use the network.
- **Network:** at run time the runner itself makes no network calls, and Claude Code is started with
  its non-essential traffic switched off. In a test run in which we logged the container's DNS
  queries, `api.anthropic.com` was the only name looked up. At build time: Docker Hub, the Debian
  mirrors and the npm registry.
- **The API key in logs.** At the end of the run (also after SIGTERM, a fatal error or the backstop)
  every output file is searched for the key and its last 20 characters, which are blanked out if
  found. We found none in test runs.
- **File ownership.** The user gets the numeric id that owns `/data/output` on the host, and read
  permission for everyone is added to all output every minute, so that `scp -r` in `run.sh` can copy
  every file. Symbolic links, pipes and sockets, which could make that copy fail, are removed at the
  end of the run.
- **The solutions are anonymous:** the write-up instructions require it, and a file that contains
  one of a list of tell-tale words (`NAMES` in `src/run.py`) is not accepted. The logs, of course,
  name model and vendor.

## Testing

```bash
docker build -t my-submission .
mkdir -p my-output
docker run --rm \
  -v $(pwd)/example/input.json:/data/input/input.json:ro \
  -v $(pwd)/my-output:/data/output \
  --env-file secrets.env \
  my-submission
```

`example/input.json` holds two easy made-up problems. Even an easy problem goes through the whole
procedure, which takes tens of minutes and roughly ten dollars a problem.

`python3 tests/test_runner.py` runs the whole pipeline against a fake `claude` command, with no
network and no key. It covers some forty ways a problem can go (solved, not proved, proved only in
part, wrong scope, an error found while writing up, crashes and API errors at each stage, hangs,
LaTeX that does not compile, 17 pages, a write-up that names its author) as well as start-up
failures, odd input files and SIGTERM. It needs `pdflatex`, `pdfinfo` and `pgrep`.

## Licence

Apache-2.0, see [LICENSE](LICENSE). `vendor/math-proof` carries its own copy of the same licence.
