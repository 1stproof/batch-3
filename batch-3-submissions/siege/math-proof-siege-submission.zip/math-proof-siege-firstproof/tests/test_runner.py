#!/usr/bin/env python3
# Copyright 2026 Anthropic PBC
# SPDX-License-Identifier: Apache-2.0
"""End-to-end tests of src/run.py with a fake 'claude' command (no network, no API key).

Needs python3, pdflatex, pdfinfo and pgrep on the PATH. Run:  python3 tests/test_runner.py
Takes about four minutes, most of it waiting for sessions that hang to reach their time limits.
"""
import json
import os
import signal
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
BLANK = "No solution is submitted"
KEY = "sk-test-not-a-real-key-0123456789"

# case name (see tests/fake_claude/claude) -> words expected in the reason for declining, or None if a
# solution is expected
CASES = {
    "proved": None,
    "crash_once": None,  # the solving session dies once and is continued
    "api_error_once": None,  # the solving session ends in an API error once and is continued
    "bold_phase": None,  # state.md says "**Phase:** **finished**"
    "other_word": None,  # state.md says "phase: complete", but the session ended normally after a verdict
    "status_prose_1": None,  # after the verdict line, the judge's Status paragraph says "Main claim: ..."
    "status_prose_2": None,  # ... or "the main claim: ..."
    "scope_hangs_after_reply": None,  # the scope check prints its closing event but the process does not exit
    "scope_error_once": None,  # the scope check fails once on an API error
    "bad_latex_once": None,  # the first write-up does not compile, the second does
    "too_long_once": None,  # the first write-up has 17 pages
    "names_the_system_once": None,  # the first write-up breaks anonymity
    "step_lost_once": None,  # the comparison with proof.md finds a step missing from the first write-up
    "latin1": None,  # solution.tex is not valid UTF-8 but compiles
    "echo_key": None,  # a shell command prints the API key into a log
    "odd_files": None,  # the session leaves a pipe and a dangling link behind
    "not_proved": "closing verdict on its main claim was NOT PROVED",
    "proved_in_part": "closing verdict on its main claim was UNCLEAR",
    "second_verdict_unclear": "closing verdict on its main claim was UNCLEAR",
    "noise_after_verdict": "closing verdict on its main claim was NOT PROVED",
    "stale_verdict": "solving time limit was reached",  # PROVED, then a failed last step: the skill never finished
    "wrong_scope": "scope check did not confirm",
    "scope_takes_it_back": "scope check did not confirm",
    "scope_error": "scope check could not be run",
    "error_found": "reported an error in the proof",
    "error_found_wordy": "reported an error in the proof",
    "crash": "solving time limit was reached",
    "hang": "solving time limit was reached",
    "bad_latex": "pdflatex stopped with an error",
    "too_long": "17 pages",
    "names_the_system": "double blind",
    "undefined_reference": "undefined references",
    "step_lost": "did not confirm that the argument is unchanged",
    "fidelity_error": "comparison of the write-up with proof.md could not be run: API Error: 529",
    "writer_dies": "did not finish (its sessions crashed)",
    "writer_api_error": "did not finish (API Error: 500)",
    "writer_hangs": "did not finish (the time limit was reached)",
    "writer_no_marker": "without the closing line",
}


def run(folder, problems, wait=True, raw_input=None, **settings):
    folder.mkdir(parents=True)
    (folder / "input.json").write_bytes(raw_input or json.dumps({"problems": problems}).encode())
    env = {
        **os.environ,
        "PATH": f"{REPO / 'tests' / 'fake_claude'}:{os.environ['PATH']}",
        "ANTHROPIC_API_KEY": KEY,
        "FP_INPUT": str(folder / "input.json"),
        "FP_OUTPUT": str(folder / "out"),
        "FP_CLAUDE_CONFIG": str(folder / "claude-code"),
        "FP_SOLVE_HOURS": "0.01",  # 36 seconds
        "FP_TOTAL_HOURS": "0.08",
        "FP_WRITEUP_MINUTES": "0.3",
        "FP_CHECK_MINUTES": "0.2",
        "FP_PREFLIGHT_SECONDS": "5",
        "FP_RESTART_PAUSE_SECONDS": "0.5",
        **settings,
    }
    proc = subprocess.Popen([sys.executable, str(REPO / "src" / "run.py")], env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if not wait:
        return proc
    log, _ = proc.communicate(timeout=600)
    return proc.returncode, log


def check(condition, message):
    print(("ok    " if condition else "FAIL  ") + message)
    if not condition:
        check.failures += 1


check.failures = 0


def main():
    top = Path(tempfile.mkdtemp(prefix="fp-test-"))
    one = [{"id": "x", "latex": "CASE: proved"}]

    print("--- all cases in one run")
    problems = [{"id": name, "latex": f"\\textbf{{Problem.}} CASE: {name}"} for name in CASES]
    code, log = run(top / "a", problems, FP_MAX_PARALLEL=str(len(problems)), CLAUDE_CODE_EFFORT_LEVEL="max")
    out = top / "a" / "out"
    check(code == 0, "exit code 0")
    results = json.loads((out / "results.json").read_text())
    for name, words in CASES.items():
        tex = (out / f"{name}.tex").read_bytes().decode("latin-1")
        if words is None:
            check(BLANK not in tex and (out / f"{name}.pdf").exists(),
                  f"{name}: solution and PDF written {results[name].get('reason', '')}")
        else:
            check(BLANK in tex and not (out / f"{name}.pdf").exists(), f"{name}: explicit no-solution file")
            check(words in results[name].get("reason", ""), f"{name}: reason has '{words}': {results[name].get('reason')}")
    solved = sum(words is None for words in CASES.values())
    progress = json.loads((out / "progress.json").read_text())
    check("timestamp_utc" in progress and f"{solved}/{len(CASES)} solutions written" in progress["status"],
          f"progress.json: {progress['status']}")
    calls = [json.loads(line) for line in (out / "token_usage.jsonl").read_text().splitlines()]
    mine = [c for c in calls if c["problem"] == "proved"]
    check(sorted(c["output_tokens"] for c in mine) == [50, 50, 50, 50, 300], "token log: final counts, one record per response")
    check({c["agent"] for c in mine} == {"main", "math-proof:math-proof-judge"}, "token log: sub-agent calls are labelled")
    check({c["step"] for c in mine} == {"siege", "scope_check", "writeup", "fidelity_check"}, "token log: every stage is labelled")
    check(sum(c["thinking_tokens"] for c in mine) == 180, "token log: thinking tokens recorded")
    summary = json.loads((out / "token_usage_summary.json").read_text())
    check(summary["total"]["api_responses"] == len(calls), "token summary agrees with the log")
    everything = list(out.rglob("*"))
    check(all(stat.S_IMODE(p.lstat().st_mode) & stat.S_IROTH for p in everything), "every output file is world-readable")
    check(all(p.is_dir() or (p.is_file() and not p.is_symlink()) for p in everything), "only plain files and directories are left")
    check(not [p for p in out.iterdir() if p.name.startswith(".")], "no temporary files left in the output directory")
    check(list((top / "a/claude-code/proved/projects").rglob("*.jsonl")) and not [p for p in everything if p.name in ("claude-code", "projects")],
          "Claude Code's own directory, with its transcripts, is outside the output directory")
    check(not [p for p in everything if p.is_file() and b"isApiErrorMessage" in p.read_bytes()], "no transcript line is in any output file")
    check(not [p for p in everything if p.is_file() and KEY[-20:].encode() in p.read_bytes()], "the API key is in no output file")

    print("--- the other two policies")
    code, _ = run(top / "b", [{"id": "np", "latex": "CASE: not_proved"}], FP_SUBMIT_POLICY="always")
    check(code == 0 and BLANK not in (top / "b/out/np.tex").read_text(), "'always': not_proved is written up")
    code, _ = run(top / "b2", one, FP_SUBMIT_POLICY="certified")
    reason = json.loads((top / "b2/out/results.json").read_text())["x"].get("reason", "")
    check(BLANK in (top / "b2/out/x.tex").read_text() and "not certified" in reason, f"'certified': declined without two certifications: {reason}")

    print("--- start-up")
    code, log = run(top / "c", one, ANTHROPIC_API_KEY="")
    check(code == 2 and "ANTHROPIC_API_KEY is not set" in log, "missing key: exit code 2 and a clear message")
    code, log = run(top / "d", one, FAKE_PREFLIGHT="bad_key")
    check(code == 2 and "HTTP 401" in log, "rejected key: exit code 2 and the HTTP status")
    check("FATAL" in json.loads((top / "d/out/progress.json").read_text())["status"], "rejected key: progress.json says so")
    check(BLANK in (top / "d/out/x.tex").read_text(), "rejected key: the no-solution file is still there")
    for mode in ("overloaded_once", "refused_once"):
        code, log = run(top / mode, one, FAKE_PREFLIGHT=mode)
        check(code == 0 and BLANK not in (top / mode / "out/x.tex").read_text(), f"start-up test {mode}: the run goes on")
    code, log = run(top / "f", one, ANTHROPIC_API_KEY=f' "{KEY}" ', FP_MAX_PARALLEL="", FP_SOLVE_HOURS="soon")
    check(code == 0 and BLANK not in (top / "f/out/x.tex").read_text(), "quoted key, empty and malformed settings: the run goes on")
    code, log = run(top / "f2", one, FP_MAX_PARALLEL="0")
    check(code == 0 and BLANK not in (top / "f2/out/x.tex").read_text(), "FP_MAX_PARALLEL=0 is read as 1")

    print("--- the backstop timer")
    code, log = run(top / "k", [{"id": "h", "latex": "CASE: hang"}, {"id": "o", "latex": "CASE: odd_files"}],
                    FP_SOLVE_HOURS="1", FP_TOTAL_HOURS="-0.495")  # the timer fires 18 seconds after the start
    left = [p for p in (top / "k/out").rglob("*") if p.is_symlink() or not (p.is_dir() or p.is_file())]
    check(code == 0 and (top / "k/out/results.json").exists() and not left, "exit code 0, results.json written, links and pipes removed")

    print("--- odd input files")
    odd = [{"id": "odd id/with $pecial_chars", "latex": "CASE: proved"}, {"id": "no-latex"}, "not a dict",
           {"id": "L" * 400, "latex": "CASE: proved"}, {"id": 7, "latex": "CASE: proved"}, {"id": "7", "latex": "CASE: proved"}]
    code, log = run(top / "g", None, raw_input=b"\xef\xbb\xbf" + json.dumps({"problems": odd}).encode())
    names = sorted(p.name for p in (top / "g/out").glob("*.tex"))
    check(code == 0 and names == sorted(["odd_id_with__pecial_chars.tex", "no-latex.tex", "problem-3.tex", "L" * 80 + ".tex", "7.tex", "7_.tex"]),
          f"byte-order mark, odd ids and malformed entries: one file each: {names}")
    check(BLANK in (top / "g/out/no-latex.tex").read_text() and BLANK not in (top / "g/out/7_.tex").read_text(),
          "a malformed entry costs only itself")
    code, log = run(top / "h", None, raw_input=b"this is not JSON")
    check(code == 2 and "is not a JSON file" in log, "unreadable input: exit code 2 and a clear message")

    print("--- SIGTERM, as sent by 'timeout' around 'docker run'")
    for name, case in (("i", "hang"), ("j", "writer_hangs")):
        proc = run(top / name, [{"id": "h", "latex": f"CASE: {case}"}], wait=False,
                   FP_SOLVE_HOURS="1", FP_TOTAL_HOURS="2", FP_WRITEUP_MINUTES="60")
        time.sleep(8)
        early = {p.name for p in (top / name / "out").iterdir()}
        check({"h.tex", "progress.json", "token_usage.jsonl", "logs"} <= early, f"{case}: outputs exist seconds after the start")
        proc.send_signal(signal.SIGTERM)
        began = time.time()
        proc.communicate(timeout=60)
        check(time.time() - began < 20, f"{case}: stops within 20 s of SIGTERM (took {time.time() - began:.0f} s)")
        check(BLANK in (top / name / "out/h.tex").read_text(), f"{case}: nothing unfinished is handed in")
        check((top / name / "out/results.json").exists(), f"{case}: results.json written on the way out")
        left = subprocess.run(["pgrep", "-f", str(top / name)], capture_output=True, text=True).stdout.split()
        check(not left, f"{case}: no session is left running")

    print(f"\n{check.failures} failure(s); files are in {top}")
    sys.exit(1 if check.failures else 0)


if __name__ == "__main__":
    main()
