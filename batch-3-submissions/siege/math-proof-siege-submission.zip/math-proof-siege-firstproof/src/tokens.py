# Copyright 2026 Anthropic PBC
# SPDX-License-Identifier: Apache-2.0
"""Token log: one record for every model response, sub-agents included.

Where the numbers come from. Claude Code saves each session as JSON lines under
$CLAUDE_CONFIG_DIR/projects/<directory>/<session>.jsonl and each sub-agent beside it in
<session>/subagents/agent-<id>.jsonl. Every model response appears there with the
"usage" object the Anthropic API returned for it. The runner gives each problem a
CLAUDE_CONFIG_DIR of its own inside the container; the transcripts are read there and are
not copied to /data/output. (The events Claude Code prints with
--output-format stream-json are NOT used for this: they carry the usage as it stood when
the response began, before its output was counted.) A response with several parts is
saved as several lines with the same message id; the last one has the final counts.

Fields, as the Anthropic API defines them:
  input_tokens                  prompt tokens that were neither read from nor written to the cache
  cache_creation_input_tokens   prompt tokens written to the prompt cache
  cache_read_input_tokens       prompt tokens read from the prompt cache
  output_tokens                 everything the model generated, hidden thinking INCLUDED
  thinking_tokens               the part of output_tokens that was thinking
                                (usage.output_tokens_details.thinking_tokens)
Total prompt size of a call = the three input fields added together.

As a cross-check, token_usage_summary.json also lists the totals that Claude Code itself
reports when a session ends. In test runs behind a logging proxy, the proxy's counts, those
totals and this log agreed exactly, call by call, including responses that were cut off at
the output limit and requested again. Those runs were short (up to about 130 calls). The one
exception: a response that was still streaming at the moment its session was killed is missing,
or is listed with the provisional counts it had when it began. A killed session also prints no closing totals. We have not
checked that the request by which a very long session summarises its own context is saved in
its transcript; if it is not, the closing totals will exceed this log by that much.
"""

import json
import os
import threading
from pathlib import Path

def closing_event(stream):
    """The "result" event Claude Code prints as its last line when a session ends, or {} if there is none."""
    try:
        with open(stream, "rb") as handle:
            handle.seek(max(0, os.path.getsize(stream) - 2_000_000))
            tail = handle.read()
    except OSError:
        return {}
    for line in reversed(tail.splitlines()):
        if line.startswith(b"{") and b'"type":"result"' in line:
            try:
                event = json.loads(line)
            except ValueError:
                continue
            if event.get("type") == "result":
                return event
    return {}


COUNTS = ("input_tokens", "cache_creation_input_tokens", "cache_read_input_tokens", "output_tokens", "thinking_tokens")


class TokenLog:
    def __init__(self, config_dirs, out):
        """config_dirs holds one CLAUDE_CONFIG_DIR per problem, named after it; the two files go to out."""
        self.config_dirs, self.out = Path(config_dirs), Path(out)
        self.lock = threading.Lock()
        self.sessions = {}  # session id -> {"problem", "step", "session_number", "stream"}
        self.read_up_to = {}  # transcript file -> bytes already read
        self.calls = {}  # API message id -> record

    def register_session(self, session, problem, step, number, stream):
        with self.lock:
            self.sessions[session] = {"problem": problem, "step": step, "session_number": number, "stream": stream}

    def output_tokens(self, problem):
        with self.lock:
            return sum(c["output_tokens"] for c in self.calls.values() if c["problem"] == problem)

    def _agent_type(self, transcript):
        """'main' for a session's own file, else the sub-agent's type, e.g. math-proof:math-proof-judge."""
        if transcript.parent.name != "subagents":
            return "main"
        try:
            return json.loads(transcript.with_suffix(".meta.json").read_text(encoding="utf-8"))["agentType"]
        except (OSError, ValueError, KeyError):
            return "sub-agent"

    def _read_new_lines(self, transcript):
        """Take in the complete lines appended to one transcript since the last call."""
        start = self.read_up_to.get(transcript, 0)
        with open(transcript, "rb") as handle:
            handle.seek(start)
            data = handle.read()
        end = data.rfind(b"\n") + 1
        self.read_up_to[transcript] = start + end
        for line in data[:end].splitlines():
            if b'"usage"' not in line or b'"assistant"' not in line:
                continue
            try:
                entry = json.loads(line)
                message = entry["message"]
                usage = message["usage"]
                if entry.get("type") != "assistant" or not message.get("id") or entry.get("isApiErrorMessage"):
                    continue  # the last case is an error notice Claude Code wrote itself, not a model response
            except (ValueError, KeyError, TypeError):
                continue
            known = self.sessions.get(entry.get("sessionId"), {})
            record = {
                "timestamp_utc": entry.get("timestamp"),
                "problem": known.get("problem", transcript.relative_to(self.config_dirs).parts[0]),
                "step": known.get("step"),
                "session_number": known.get("session_number"),
                "session_id": entry.get("sessionId"),
                "agent": self._agent_type(transcript),
                "agent_id": entry.get("agentId"),
                "model": message.get("model"),
                "message_id": message["id"],
                "request_id": entry.get("requestId"),
                "stop_reason": message.get("stop_reason"),
                "input_tokens": usage.get("input_tokens") or 0,
                "cache_creation_input_tokens": usage.get("cache_creation_input_tokens") or 0,
                "cache_read_input_tokens": usage.get("cache_read_input_tokens") or 0,
                "output_tokens": usage.get("output_tokens") or 0,
                "thinking_tokens": (usage.get("output_tokens_details") or {}).get("thinking_tokens"),
            }
            earlier = self.calls.get(record["message_id"])
            if earlier is None or record["output_tokens"] >= earlier["output_tokens"]:
                self.calls[record["message_id"]] = record

    def _reported_by_claude_code(self):
        """The closing 'result' event of every session that has ended normally."""
        reports = []
        for session, known in self.sessions.items():
            if "report" not in known:
                result = closing_event(known["stream"])
                if not result:
                    continue
                known["report"] = {
                    "problem": known["problem"], "step": known["step"], "session_number": known["session_number"],
                    "session_id": session, "cost_usd_at_list_price": result.get("total_cost_usd"),
                    "per_model": result.get("modelUsage"),
                }
            reports.append(known["report"])
        return reports

    def update(self):
        """Read what is new and rewrite token_usage.jsonl and token_usage_summary.json."""
        with self.lock:
            for transcript in sorted(self.config_dirs.glob("*/projects/**/*.jsonl")):
                try:
                    self._read_new_lines(transcript)
                except OSError:
                    pass
            calls = sorted(self.calls.values(), key=lambda c: c["timestamp_utc"] or "")
            reports = self._reported_by_claude_code()

        def total(selected):
            selected = list(selected)
            sums = {name: sum(c[name] or 0 for c in selected) for name in COUNTS}
            return {"api_responses": len(selected), **sums}

        def split(key):
            return {str(v): total(c for c in calls if c[key] == v) for v in sorted({c[key] for c in calls}, key=str)}

        summary = {
            "note": "output_tokens includes thinking_tokens. One line per API response is in token_usage.jsonl. "
                    "Field meanings and sources are described at the top of src/tokens.py.",
            "total": total(calls),
            "by_problem": split("problem"),
            "by_step": split("step"),
            "by_agent": split("agent"),
            "by_model": split("model"),
            "totals_reported_by_claude_code_for_finished_sessions": reports,
        }
        self._replace("token_usage.jsonl", "".join(json.dumps(c) + "\n" for c in calls))
        self._replace("token_usage_summary.json", json.dumps(summary, indent=2) + "\n")

    def _replace(self, name, text):
        tmp = self.out / f".{name}.{threading.get_ident()}.tmp"
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, self.out / name)
