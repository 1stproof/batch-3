#!/usr/bin/env python3
# Copyright 2026 Anthropic PBC
# SPDX-License-Identifier: Apache-2.0
"""Runner for the First Proof Batch 3 container.

For every problem in /data/input/input.json, in parallel and each in its own
directory:

  1. solve     one headless Claude Code session runs the public skill
               "/math-proof:siege problem.md" (vendor/math-proof, unmodified).
               If the session dies before the skill has finished, the same
               command is given again in the same directory, which is how the
               skill's README says to continue a stopped run.
  2. decide    a solution is submitted only if the skill finished, its own
               verdict is "MAIN CLAIM: PROVED", and a fresh session confirms
               that the claim it proved is the problem as posed.
  3. write up  a fresh session turns the skill's proof.md into LaTeX; this
               script compiles it in an empty directory and counts the pages,
               and another fresh session compares it with proof.md.

/data/output/<id>.tex starts as a "no solution submitted" page and is replaced
only when all three stages succeed, so a kill at any moment leaves a valid file
for every problem. (The setting FP_SUBMIT_POLICY can tighten stage 2 or switch
it off.) progress.json and the token log are rewritten every minute.

Python standard library only. Settings are environment variables; see SETTINGS.
"""

import json
import math
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from tokens import TokenLog, closing_event

START = time.monotonic()  # every deadline below is measured from container start


def setting(name, default):
    """Read one setting from the environment, converted to the default's type."""
    try:
        return type(default)(os.environ.get(name) or default)
    except ValueError:
        print(f"ignoring {name}={os.environ[name]!r}: not a valid value; using {default!r}", flush=True)
        return default


# ---- SETTINGS (they can be added to the secrets file; the defaults are what we submit) ----
MODEL = setting("FP_MODEL", "claude-opus-5-5")  # requested for every session; sub-agents inherit it
EFFORT = setting("FP_EFFORT", "high")  # main sessions only; sub-agents keep the plugin's own levels
# What is handed in (a wrong proof scores below a blank one):
#   "verified"   only what passed stage 2
#   "certified"  as "verified", and two separate workers must have certified the proof during the rounds
#   "always"     whatever proof.md the skill wrote, with its gaps stated in the text
SUBMIT_POLICY = setting("FP_SUBMIT_POLICY", "verified")
SIEGE_SETTINGS = setting("FP_SIEGE_SETTINGS", "")  # e.g. "MAX_ROUNDS=10"; empty = the skill's defaults
MAX_PARALLEL = max(1, setting("FP_MAX_PARALLEL", 10))  # problems worked on at the same time
SOLVE_HOURS = setting("FP_SOLVE_HOURS", 20.0)  # stage 1 is stopped this long after container start
TOTAL_HOURS = setting("FP_TOTAL_HOURS", 22.5)  # no session runs later than this
PREFLIGHT_SECONDS = setting("FP_PREFLIGHT_SECONDS", 300.0)  # time allowed to each start-up test request
RESTART_PAUSE_SECONDS = setting("FP_RESTART_PAUSE_SECONDS", 60.0)  # wait before continuing a dead session
STALL_MINUTES = setting("FP_STALL_MINUTES", 120.0)  # no run file or transcript written for this long = hung session
MAX_OUTPUT_TOKENS = setting("FP_MAX_OUTPUT_TOKENS_PER_PROBLEM", 40_000_000)  # runaway guard for stage 1
WRITEUP_ATTEMPTS = setting("FP_WRITEUP_ATTEMPTS", 3)  # write-ups that may fail a check other than the page limit
PAGE_ATTEMPTS = setting("FP_PAGE_ATTEMPTS", 4)  # write-ups that may come out too long
WRITEUP_MINUTES = setting("FP_WRITEUP_MINUTES", 60.0)  # per write-up session
CHECK_MINUTES = setting("FP_CHECK_MINUTES", 30.0)  # per scope-check or comparison session
MAX_PAGES = 16

INPUT = Path(setting("FP_INPUT", "/data/input/input.json"))
OUT = Path(setting("FP_OUTPUT", "/data/output"))
LOGS = OUT / "logs"
# Claude Code's own configuration directories, one per problem. It saves its settings, caches and session
# transcripts there. They are that program's working files, not results, and stay inside the container.
CONFIG_DIRS = Path(setting("FP_CLAUDE_CONFIG", str(Path.home() / "claude-code")))
APP = Path(__file__).resolve().parent
PLUGIN = APP.parent / "vendor" / "math-proof"

# Environment of every Claude Code session. The first three lines are the block the
# plugin's README asks for. The two variables set to None are removed if present: they
# would override the effort and model that the plugin sets for each kind of sub-agent.
CLAUDE_ENV = {
    "CLAUDE_CODE_MAX_OUTPUT_TOKENS": "128000",
    "CLAUDE_CODE_DISABLE_BACKGROUND_TASKS": "1",
    "CLAUDE_ASYNC_AGENT_STALL_TIMEOUT_MS": "14400000",
    "CLAUDE_CODE_RETRY_WATCHDOG": "1",  # wait out 429/529 responses instead of failing after 10 tries
    "API_TIMEOUT_MS": "3600000",
    "DISABLE_AUTOUPDATER": "1",
    "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
    "CLAUDE_CODE_EFFORT_LEVEL": None,
    "CLAUDE_CODE_SUBAGENT_MODEL": None,
}

# Why this script stopped a session (the "stopped" field that run_claude returns).
BY_SIGNAL = "the container was told to stop"
BY_TIME = "the time limit was reached"
BY_STALL = f"nothing was written for {STALL_MINUTES:g} minutes"
BY_TOKENS = f"the problem passed the guard of {MAX_OUTPUT_TOKENS:,} output tokens"

STOP = threading.Event()  # set by a signal, and at the end of the run: wind down at once
LOCK = threading.Lock()
RUNNING = set()  # live Claude Code processes
STATUS = {}  # problem id -> {"stage": ..., "outcome": ..., ...}; shown in progress.json
TOKENS = TokenLog(CONFIG_DIRS, OUT)
HEARTBEAT = None  # the thread that rewrites progress.json and the token log


def elapsed_hours():
    return (time.monotonic() - START) / 3600


def at_hours(h):
    """The time.monotonic() value that lies h hours after container start."""
    return START + h * 3600


def utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def say(pid, text):
    print(f"{utc_now()} [{pid}] {text}\n", end="", flush=True)  # one write, so that threads' lines do not mix


def write_atomic(path, data):
    """Replace a file in one step, so a kill never leaves it half written."""
    tmp = path.with_name(f".{path.name}.{threading.get_ident()}.tmp")
    tmp.write_bytes(data if isinstance(data, bytes) else data.encode("utf-8"))
    os.replace(tmp, path)


def set_status(pid, **fields):
    with LOCK:
        STATUS.setdefault(pid, {}).update(fields)


def without_key():
    """The environment for helper programs (pdflatex, pdfinfo, ledger.py), which need no API key."""
    return {name: value for name, value in os.environ.items() if name != "ANTHROPIC_API_KEY"}


# ---------------------------------------------------------------- Claude Code sessions


def kill(proc):
    """End a session's whole process group: ask first, then force. Also called after a session
    has ended by itself, to clear away anything it left running. (A shell command that the
    session started in a group of its own can outlive this; it ends with the container.)"""
    for sig, wait in ((signal.SIGTERM, 10), (signal.SIGKILL, 5)):
        try:
            os.killpg(proc.pid, sig)
            proc.wait(timeout=wait)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            pass


def newest_write(folder):
    """Time of the most recent file write anywhere under folder (0 if there is none). The files
    of printed events do not count: Claude Code adds keep-alive lines to them even while it waits."""
    newest = 0.0
    for root, _, files in os.walk(folder):
        for name in files:
            if name.endswith(".stream.jsonl"):
                continue
            try:
                newest = max(newest, os.lstat(os.path.join(root, name)).st_mtime)
            except OSError:
                pass
    return newest


def run_claude(pid, step, prompt, cwd, deadline, extra=()):
    """Run one headless Claude Code session to its end, or stop it at the deadline.

    Returns a dict: "stopped" (None, or one of the BY_... reasons above), "result"
    (Claude Code's closing "result" event, or {} if it never printed one), "stream"
    (the file holding everything the session printed) and "reply" (the session's
    final message, or "" if it crashed, ended in an error, or was stopped before it had
    printed its closing event).
    """
    folder, config = LOGS / pid, CONFIG_DIRS / pid
    number = len(list(folder.glob(f"{step}.*.stream.jsonl"))) + 1
    stream = folder / f"{step}.{number}.stream.jsonl"
    session = str(uuid.uuid4())
    TOKENS.register_session(session, pid, step, number, stream)
    command = ["claude", "-p", prompt, "--model", MODEL, "--effort", EFFORT, "--session-id", session]
    command += ["--dangerously-skip-permissions", "--output-format", "stream-json", "--verbose", *extra]
    environment = {**os.environ, **CLAUDE_ENV, "CLAUDE_CONFIG_DIR": str(config)}
    environment = {name: value for name, value in environment.items() if value is not None}
    say(pid, f"{step} session {number} starts")
    with open(stream, "wb") as out, open(stream.with_suffix(".stderr.txt"), "wb") as err:
        try:
            proc = subprocess.Popen(command, cwd=cwd, env=environment, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, start_new_session=True)
        except OSError as error:  # counts as a session that died at once
            err.write(f"the 'claude' command could not be started: {error}".encode())
            say(pid, f"{step} session {number} could not be started: {error}")
            return {"stopped": None, "result": {}, "stream": stream, "reply": ""}
    with LOCK:
        RUNNING.add(proc)
    stopped, next_check = None, time.monotonic() + 60
    while proc.poll() is None and not stopped:
        time.sleep(2)
        if proc.poll() is not None:
            break
        if STOP.is_set():
            stopped = BY_SIGNAL
        elif time.monotonic() > deadline:
            stopped = BY_TIME
        elif time.monotonic() > next_check:
            next_check = time.monotonic() + 60
            if time.time() - max(newest_write(folder), newest_write(config)) > STALL_MINUTES * 60:
                stopped = BY_STALL
            elif step == "siege" and TOKENS.output_tokens(pid) > MAX_OUTPUT_TOKENS:
                stopped = BY_TOKENS
    kill(proc)
    with LOCK:
        RUNNING.discard(proc)
    result = closing_event(stream)
    failed = not result or result.get("is_error")  # a session that hangs after its closing event has still replied
    how = f"stopped because {stopped}" if stopped else result.get("subtype", "no closing event")
    say(pid, f"{step} session {number} ended: exit code {proc.returncode}, {how}")
    return {"stopped": stopped, "result": result, "stream": stream, "reply": "" if failed else str(result.get("result", ""))}


def run_short_session(pid, step, prompt, cwd, minutes, tools):
    """A stage 2 or 3 session. One that crashes or ends in an API error says nothing about the
    mathematics, so it is started afresh after a pause that doubles up to 15 minutes: seven
    sessions over about 45 minutes, if the overall deadline allows."""
    for attempt in range(7):
        deadline = min(time.monotonic() + minutes * 60, at_hours(TOTAL_HOURS))
        outcome = run_claude(pid, step, prompt, cwd, deadline, ["--tools", tools])
        pause = min(RESTART_PAUSE_SECONDS * 2**attempt, 900)
        if outcome["reply"] or outcome["stopped"] or attempt == 6 or time.monotonic() + pause > at_hours(TOTAL_HOURS):
            break
        if STOP.wait(pause):
            break
    return outcome


def why_no_reply(outcome):
    """In words, why a session gave no usable reply."""
    return outcome["stopped"] or str(outcome["result"].get("result") or "its sessions crashed")[:200]


def last_line(reply):
    """The last line of a reply that holds any words, without surrounding punctuation or Markdown marks."""
    lines = [re.sub(r"^\W+|\W+$", "", line) for line in reply.splitlines()]
    return ([""] + [line for line in lines if line])[-1]


def prompt_text(name, **slots):
    text = (APP / "prompts" / name).read_text(encoding="utf-8")
    for key, value in slots.items():
        text = text.replace("{" + key + "}", str(value))
    return text


# ---------------------------------------------------------------- stage 1: solve


def phase(run_dir):
    """The skill's current phase, from the last 'phase:' line of the state.md it keeps,
    e.g. 'round 3 plan, attempt 1' or 'finished'."""
    try:
        text = (run_dir / "state.md").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "starting"
    found = re.findall(r"^\W*(?:current )?phase\W*:\W*(.+?)\W*$", text, re.M | re.I)
    return found[-1] if found else "starting"


def main_claim_verdict(pid):
    """The skill's own final verdict: 'PROVED', 'NOT PROVED', 'UNCLEAR: ...', or None if it gave none.

    The skill's last judge step begins its reply with "MAIN CLAIM: PROVED" or "MAIN CLAIM:
    NOT PROVED", then a dash and the claim. That reply is not saved in a run file. It reaches
    the main session as the result of a sub-agent call (Claude Code puts a notice before it and
    indents it), so it is read from the events the session printed. Only the result of the main
    session's very last sub-agent call counts: the skill launches nothing after its last judge
    step, so if that result carries no verdict, the skill did not get to its end.
    """
    verdict, agent_calls = None, set()
    for stream in sorted((LOGS / pid).glob("siege.*.stream.jsonl"), key=lambda p: int(p.name.split(".")[1])):
        with open(stream, encoding="utf-8", errors="replace") as lines:
            for line in lines:
                if '"tool_use"' not in line and '"tool_result"' not in line:
                    continue
                try:
                    event = json.loads(line)
                    blocks = event["message"]["content"]
                except (ValueError, KeyError, TypeError):
                    continue
                if event.get("parent_tool_use_id") or not isinstance(blocks, list):
                    continue  # an event from inside a sub-agent, or plain text
                for block in blocks:
                    if not isinstance(block, dict):
                        continue
                    if block.get("type") == "tool_use" and block.get("name") in ("Task", "Agent"):
                        agent_calls.add(block.get("id"))
                    if block.get("type") != "tool_result" or block.get("tool_use_id") not in agent_calls:
                        continue
                    content = block.get("content")
                    if isinstance(content, list):
                        content = "\n".join(c.get("text", "") for c in content if isinstance(c, dict))
                    verdict = verdict_in(str(content))
    return verdict


def verdict_in(reply):
    """The verdict that one judge reply carries, or None. Anything but a plain PROVED or NOT PROVED at
    the start of a line, and any reply that mentions two different verdicts, is UNCLEAR, which counts
    as not proved."""
    reply = re.sub(r"[*_`]", "", reply)  # Markdown emphasis
    mentions = re.findall(r"MAIN CLAIM\s*:\s*(.*)$", reply, re.M)  # capitals only: "the main claim: ..." is prose
    if not mentions:
        return None
    found = set()
    for rest in mentions:
        # the word, then the end of the line, a dash set off by a space, a long dash or a punctuation mark
        plain = re.match(r"(NOT PROVED|PROVED)(?:\s*$|\s+-|\s*[\u2012-\u2015\u2212:.,;])", rest)
        found.add(plain.group(1) if plain else None)
    if len(found) == 1 and None not in found and re.search(r"^\W*MAIN CLAIM\s*:", reply, re.M):
        return found.pop()
    return "UNCLEAR: the judge wrote 'MAIN CLAIM: " + " / ".join(mentions)[:150] + "'"


def solve(pid, work, deadline):
    """Run the skill to its end. Returns None, or the reason why it did not get there."""
    run_dir = work / "math-proof-run"
    prompt = " ".join(["/math-proof:siege", *SIEGE_SETTINGS.split(), "problem.md"])
    sessions = fruitless = 0  # fruitless: sessions in a row that lasted under 5 minutes or wrote nothing
    while True:
        if TOKENS.output_tokens(pid) > MAX_OUTPUT_TOKENS:
            return f"{BY_TOKENS} in phase '{phase(run_dir)}', session {sessions}"
        sessions += 1
        set_status(pid, stage="solving", sessions=sessions)
        before, began = newest_write(run_dir), time.monotonic()
        outcome = run_claude(pid, "siege", prompt, work, deadline, ["--plugin-dir", str(PLUGIN)])
        if re.match(r"finished\b(?!\s+\w)", phase(run_dir), re.I):  # "finished", not "finished round 3, next ..."
            return None
        if outcome["reply"] and (run_dir / "proof.md").is_file() and main_claim_verdict(pid) == "PROVED":
            return None  # ended normally right after the closing verdict; only state.md's wording differs
        where = f"in phase '{phase(run_dir)}', session {sessions}"
        if outcome["result"].get("is_error"):
            where += f" (that session ended with: {str(outcome['result'].get('result'))[:200]})"
        if outcome["stopped"] == BY_TIME:
            return f"the solving time limit was reached {where}"
        if outcome["stopped"] in (BY_SIGNAL, BY_TOKENS):
            return f"{outcome['stopped']} {where}"
        # The session died, hung or gave up (an outage, a crash, a full context window): continue it.
        fruitless = fruitless + 1 if newest_write(run_dir) == before or time.monotonic() - began < 300 else 0
        pause = min(RESTART_PAUSE_SECONDS * 2**fruitless, 900)
        if time.monotonic() + pause > deadline:
            return f"the solving time limit was reached {where}"
        if STOP.wait(pause):
            return f"{BY_SIGNAL} {where}"


# ---------------------------------------------------------------- stage 3: LaTeX

# Words that would tell a referee who or what wrote a solution (unless the problem itself uses them).
# The search ignores case, except for "AI" (so that, say, "the Ai function" passes).
NAMES = (r"\b(claude|anthropic|opus|sonnet|haiku|fable|openai|chatgpt|gpt|gemini|chatbot|language\s+models?|LLMs?|math-proof|siege"
         r"|proof\.md|artificial\s+intelligence|(?:an|the|by)\s+(?-i:AI)|(?-i:AI)\s+(?:systems?|models?|assistants?|agents?)"
         r"|(?:(?-i:AI)|machine)[-\s]generated|sub-?agents?)\b")


def no_solution_tex(pid):
    safe = re.sub(r"([#$%&_{}])", r"\\\1", pid)
    return (
        "\\documentclass[11pt]{article}\n\\begin{document}\n"
        f"\\noindent\\textbf{{Problem {safe}.}} No solution is submitted for this problem.\n"
        "\\end{document}\n"
    )


def check_tex(tex, keep_as):
    """Compile a copy of tex alone in an empty temporary directory and check the result. Returns None
    if all is well (that copy and its PDF are then saved as keep_as.tex and keep_as.pdf), else a
    complaint for the writer."""
    if not tex.is_file():
        return "solution.tex does not exist."
    with tempfile.TemporaryDirectory() as scratch:
        shutil.copy(tex, Path(scratch, "solution.tex"))
        command = ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "-no-shell-escape", "solution.tex"]
        for _ in range(3):  # repeated so that cross-references settle
            try:
                run = subprocess.run(command, cwd=scratch, env=without_key(), stdin=subprocess.DEVNULL,
                                     capture_output=True, timeout=300)
            except subprocess.TimeoutExpired:
                return "pdflatex did not finish within 5 minutes."
            if run.returncode != 0:
                tail = run.stdout.decode("utf-8", "replace")[-3000:]
                return f"pdflatex stopped with an error when solution.tex was compiled alone in an empty directory.\nThe end of its log:\n{tail}"
        if b"undefined references" in run.stdout or b"undefined citations" in run.stdout:
            return "After three pdflatex passes the log still reports undefined references or citations."
        try:
            info = subprocess.run(["pdfinfo", "solution.pdf"], cwd=scratch, env=without_key(), capture_output=True,
                                  text=True, errors="replace", timeout=60).stdout
        except subprocess.TimeoutExpired:
            info = ""
        pages = re.search(r"^Pages:\s+(\d+)", info, re.M)
        if not pages:
            return "pdfinfo could not read the compiled PDF."
        if int(pages.group(1)) > MAX_PAGES:
            return (f"The compiled PDF has {pages.group(1)} pages, {int(pages.group(1)) - MAX_PAGES} over the limit of {MAX_PAGES} (references included). "
                    "You may use 10pt type with one-inch margins, tighten the prose, cite standard results precisely instead of "
                    "re-proving them, and give routine verifications in one line. Keep every step a referee needs.")
        text = Path(scratch, "solution.tex").read_text(encoding="utf-8", errors="replace") + info
        posed = (tex.parent / "problem.md").read_text(encoding="utf-8", errors="replace").lower()
        named = [m for m in re.finditer(NAMES, text, re.I) if m.group(0).lower() not in posed]
        if named:
            line = text.count("\n", 0, named[0].start()) + 1
            return (f"Review is double blind, but solution.tex (line {line}) or its PDF metadata contains '{named[0].group(0)}'. Remove every "
                    "hint at who or what wrote the text. (If this is an author's first name in a reference, use the initial.)")
        for suffix in (".tex", ".pdf"):
            shutil.copy(Path(scratch, "solution" + suffix), keep_as.with_suffix(suffix))
    return None


class CouldNotRun(Exception):
    """A check gave no answer at all, which says nothing about the file it was to check."""


def check_fidelity(pid, folder):
    """Have a fresh read-only session compare folder/checked.tex with folder/proof.md. Returns None
    if it finds the same complete argument in both, else a complaint for the writer."""
    outcome = run_short_session(pid, "fidelity_check", prompt_text("fidelity_check.md"), folder, CHECK_MINUTES, "Read")
    if last_line(outcome["reply"]) == "VERDICT: SUBMIT":
        return None
    if not outcome["reply"]:
        raise CouldNotRun(why_no_reply(outcome))
    return ("An independent comparison of solution.tex with proof.md did not confirm that the argument is unchanged and complete.\n"
            "Its report:\n" + outcome["reply"][-4000:])


def write_up(pid, folder):
    """Turn folder/proof.md into folder/checked.tex and folder/checked.pdf.
    Returns None, or the reason why there is no acceptable file."""
    gaps = prompt_text("writeup_gaps_always.md" if SUBMIT_POLICY == "always" else "writeup_gaps_verified.md")
    complaint, complaints, too_long = None, [], 0
    while too_long < PAGE_ATTEMPTS and len(complaints) - too_long < WRITEUP_ATTEMPTS:
        if len(complaints) > 1:  # so that curing one fault does not bring an earlier one back
            complaint += "\n\nThe attempts before that one failed as follows; these faults must not come back:\n" + "\n".join(complaints[:-1])
        earlier = prompt_text("writeup_retry.md", COMPLAINT=complaint) if complaint else ""
        prompt = prompt_text("writeup.md", MAX_PAGES=MAX_PAGES, GAPS=gaps, EARLIER=earlier)
        outcome = run_short_session(pid, "writeup", prompt, folder, WRITEUP_MINUTES, "Read,Write,Edit,Bash")
        if SUBMIT_POLICY != "always" and re.search(r"^\W*WRITEUP: ERROR", outcome["reply"], re.M):
            return f"the write-up session reported an error in the proof (its reply is the last event in logs/{pid}/{outcome['stream'].name})"
        if not outcome["reply"]:
            complaint = f"The session did not finish ({why_no_reply(outcome)}), so solution.tex may be unfinished."
        elif last_line(outcome["reply"]) != "WRITEUP: DONE":
            complaint = "The session ended without the closing line WRITEUP: DONE, so solution.tex may be unfinished."
        else:
            try:
                complaint = check_tex(folder / "solution.tex", folder / "checked") or check_fidelity(pid, folder)
            except CouldNotRun as why:
                return f"the comparison of the write-up with proof.md could not be run: {why}"
        if complaint is None:
            return None
        say(pid, "write-up not accepted: " + complaint.splitlines()[0])
        complaints.append(complaint.splitlines()[0])
        too_long += complaint.startswith("The compiled PDF has")
        if STOP.is_set() or time.monotonic() > at_hours(TOTAL_HOURS):
            break
    return "no write-up passed the checks. " + " ".join(f"Attempt {n}: {c}" for n, c in enumerate(complaints, 1))


# ---------------------------------------------------------------- one problem, start to end


def work_on(problem, solve_seconds):
    pid = problem["id"]
    work, folder = LOGS / pid / "work", LOGS / pid / "writeup"
    work.mkdir(parents=True, exist_ok=True)
    folder.mkdir(parents=True, exist_ok=True)
    (work / "problem.md").write_text(problem["latex"], encoding="utf-8", errors="replace")
    proof = work / "math-proof-run" / "proof.md"

    def decline(reason):
        say(pid, "no solution submitted: " + reason)
        set_status(pid, stage="done", outcome="no solution submitted", reason=reason)

    if not problem["latex"].strip():
        return decline("the input file gives no 'latex' text for this problem")
    unfinished = solve(pid, work, min(time.monotonic() + solve_seconds, at_hours(SOLVE_HOURS)))
    verdict = main_claim_verdict(pid)
    # The plugin's own read-only test of its ledger: "CONCLUDE" = two separate workers certified the proof
    # during the rounds. By default it is only recorded: the skill can also reach PROVED through its longer
    # closing procedure (more proof attempts, a line-by-line check, repairs), and the test looks only at the
    # newest goal, so it says REJECT when a proved goal was followed by an unreached, more ambitious one.
    try:
        gate = subprocess.run(["python3", str(PLUGIN / "skills/siege/scripts/ledger.py"), "gate", str(proof.parent)],
                              env=without_key(), capture_output=True, text=True, timeout=60).stdout.strip()
    except (OSError, subprocess.SubprocessError) as error:
        gate = f"not available: {error}"
    set_status(pid, skill_finished=not unfinished, skill_verdict=verdict, skill_ledger_gate=gate[:200])
    if not proof.is_file():
        return decline(f"the skill wrote no proof.md: {unfinished or 'it ended without one'}")
    shutil.copy(work / "problem.md", folder / "problem.md")
    shutil.copy(proof, folder / "proof.md")

    if SUBMIT_POLICY != "always":
        if unfinished:
            return decline(f"the skill did not finish: {unfinished}")
        if verdict != "PROVED":
            return decline(f"the skill's closing verdict on its main claim was {verdict}" if verdict else
                           f"the skill gave no closing verdict (no 'MAIN CLAIM:' line in its last judge reply, see logs/{pid}/siege.*.stream.jsonl)")
        if SUBMIT_POLICY == "certified" and not gate.startswith("CONCLUDE"):
            return decline(f"the proof was not certified by two separate workers during the rounds ({gate[:200]})")
        set_status(pid, stage="checking that the proved claim is the problem as posed")
        outcome = run_short_session(pid, "scope_check", prompt_text("scope_check.md"), folder, CHECK_MINUTES, "Read")
        if not outcome["reply"]:
            return decline(f"the scope check could not be run: {why_no_reply(outcome)}")
        if last_line(outcome["reply"]) != "VERDICT: SUBMIT":
            return decline("the scope check did not confirm that proof.md settles the problem as posed")

    set_status(pid, stage="writing LaTeX")
    reason = write_up(pid, folder)
    if reason:
        return decline(reason)
    write_atomic(OUT / f"{pid}.tex", (folder / "checked.tex").read_bytes())
    write_atomic(OUT / f"{pid}.pdf", (folder / "checked.pdf").read_bytes())
    say(pid, "solution written")
    set_status(pid, stage="done", outcome="solution submitted")


def work_on_safely(problem, solve_seconds):
    """One problem's failure must never reach the others."""
    try:
        if not STOP.is_set():
            work_on(problem, solve_seconds)
    except Exception as error:
        reason = f"an error in the runner, affecting this problem only: {type(error).__name__}: {str(error)[:300]}"
        say(problem["id"], reason)
        set_status(problem["id"], stage="done", outcome="no solution submitted", reason=reason)


# ---------------------------------------------------------------- housekeeping


def make_readable(final=False):
    """Keep everything in /data/output readable by the host user who copies it out, whatever
    mode a session gave its files. At the very end, also remove our own temporary files and
    whatever is not a plain file or directory (a dangling link or a pipe would make a recursive
    copy fail)."""
    if final:
        for leftover in OUT.glob(".*.tmp"):
            try:
                leftover.unlink()
            except OSError:
                pass
    for root, dirs, files in os.walk(OUT):
        for name in dirs + files:
            path = os.path.join(root, name)
            try:
                mode = os.lstat(path).st_mode
                if os.path.islink(path) or not (os.path.isdir(path) or os.path.isfile(path)):
                    if final:
                        os.unlink(path)
                    continue
                os.chmod(path, mode | (0o555 if os.path.isdir(path) else 0o444))
            except OSError:
                pass


def redact_key():
    """Should the API key, or its last 20 characters, have been echoed into a log, blank it out."""
    key = os.environ.get("ANTHROPIC_API_KEY", "").encode()
    if len(key) < 20:
        return
    for root, _, files in os.walk(OUT):
        for name in files:
            path = Path(root, name)
            try:
                if path.is_symlink() or not path.is_file():
                    continue
                data = path.read_bytes()
                if key[-20:] in data:
                    path.write_bytes(data.replace(key, b"[API KEY REMOVED]").replace(key[-20:], b"[API KEY REMOVED]"))
            except OSError:
                pass


def write_progress(note=None):
    with LOCK:
        problems = json.loads(json.dumps(STATUS))
    for pid, entry in problems.items():
        if entry.get("stage") == "solving":
            entry["skill_phase"] = phase(LOGS / pid / "work" / "math-proof-run")
        entry["output_tokens_so_far"] = TOKENS.output_tokens(pid)
    outcomes = [p.get("outcome") for p in problems.values()]
    status = note or (
        f"{outcomes.count('solution submitted')}/{len(outcomes)} solutions written, "
        f"{outcomes.count('no solution submitted')} declined, {outcomes.count(None)} in progress"
    )
    progress = {"timestamp_utc": utc_now(), "status": status, "elapsed_hours": round(elapsed_hours(), 2), "problems": problems}
    write_atomic(OUT / "progress.json", json.dumps(progress, indent=2) + "\n")


def heartbeat():
    while not STOP.wait(60):
        for task in (TOKENS.update, write_progress, make_readable):
            try:
                task()
            except Exception as error:  # the heartbeat must outlive any hiccup
                print(f"{utc_now()} heartbeat: {task.__name__} failed: {error!r}", flush=True)


def close_down(note=None):
    """The last steps of every run, normal or not. Each is tried even if an earlier one fails."""
    STOP.set()
    if HEARTBEAT:
        HEARTBEAT.join(timeout=60)
    with LOCK:
        leftovers = list(RUNNING)

    def write_results():
        with LOCK:
            write_atomic(OUT / "results.json", json.dumps(STATUS, indent=2) + "\n")

    steps = [*(lambda p=p: kill(p) for p in leftovers), TOKENS.update, lambda: write_progress(note), write_results,
             lambda: make_readable(final=True), redact_key]
    for step in steps:
        try:
            step()
        except Exception as error:
            print(f"{utc_now()} closing down: a step failed: {error!r}", flush=True)


def stop_everything(signum, _frame):
    STOP.set()
    print(f"{utc_now()} received signal {signum}: stopping", flush=True)


def give_up_waiting():
    """Backstop. Every step has its own time limit, so the run should be over well before this
    fires, half an hour after TOTAL_HOURS. If something hangs all the same: allow the closing
    steps three minutes, then leave. The solutions are on disk already."""
    print(f"{utc_now()} still running {elapsed_hours():.2f} hours after the start: closing down now", flush=True)
    closing = threading.Thread(target=close_down, args=("stopped by the runner's backstop timer",), daemon=True)
    closing.start()
    closing.join(180)
    os._exit(0)


def fatal(message):
    print(f"{utc_now()} FATAL: {message}", file=sys.stderr, flush=True)
    close_down("FATAL: " + message)
    sys.exit(2)


def preflight():
    """One tiny request through Claude Code itself, so that a bad key, an unknown model or a
    refused client version stops the container in its first minutes with a clear message.
    Fatal are only a definite refusal that is repeated for ten minutes (twice PREFLIGHT_SECONDS)
    and a Claude Code that exits three times running without printing anything. Overload, rate
    limits and slow networks are not: try for up to about half an hour, then go on regardless."""
    folder = LOGS / "_preflight"
    folder.mkdir(parents=True, exist_ok=True)
    crashes, refused_since = 0, None
    while elapsed_hours() < 0.5 and not STOP.is_set():
        outcome = run_claude("_preflight", "preflight", "Reply with the single word READY.", folder,
                             time.monotonic() + PREFLIGHT_SECONDS, ["--tools", ""])
        result = outcome["result"]
        if outcome["reply"]:
            say("_preflight", f"the model answered; Claude Code's record of the call: {json.dumps(result.get('modelUsage'))}")
            return
        refused = result.get("api_error_status") in (400, 401, 403, 404)
        refused_since = (refused_since or time.monotonic()) if refused else None
        if refused and time.monotonic() - refused_since > 2 * PREFLIGHT_SECONDS:
            fatal(f"the Anthropic API keeps refusing test requests for model {MODEL} (HTTP {result['api_error_status']}): "
                  f"{result.get('result')} Check ANTHROPIC_API_KEY in the secrets file and that its account may use this model.")
        crashes = 0 if result or outcome["stopped"] else crashes + 1
        if crashes == 3:
            stderr = outcome["stream"].with_suffix(".stderr.txt").read_text(errors="replace")[-500:]
            fatal(f"Claude Code exited three times without any output. Its error output: {stderr or '(empty)'}")
        print(f"{utc_now()} preflight: no reply yet ({outcome['stopped'] or result.get('result') or 'no output'}); "
              f"trying again in {RESTART_PAUSE_SECONDS:g} seconds", flush=True)
        STOP.wait(RESTART_PAUSE_SECONDS)


def load_problems():
    """Read the input file. Whatever is odd about one entry must not cost the other entries."""
    data = json.loads(INPUT.read_bytes().decode("utf-8-sig", errors="replace"))
    entries = data["problems"] if isinstance(data, dict) else data
    problems, seen = [], set()
    for number, entry in enumerate(entries, 1):
        entry = entry if isinstance(entry, dict) else {}
        # The id becomes a file name: keep letters, digits, dot, dash, underscore; keep it short and unique.
        pid = re.sub(r"[^A-Za-z0-9._-]", "_", str(entry.get("id") or "")).lstrip("._")[:80] or f"problem-{number}"
        while pid in seen:
            pid += "_"
        seen.add(pid)
        problems.append({"id": pid, "latex": str(entry.get("latex") or "")})
    return problems


def main():
    global HEARTBEAT
    for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(signum, stop_everything)
    backstop = threading.Timer((TOTAL_HOURS + 0.5) * 3600, give_up_waiting)
    backstop.daemon = True
    backstop.start()
    os.umask(0o022)
    LOGS.mkdir(parents=True, exist_ok=True)
    CONFIG_DIRS.mkdir(parents=True, exist_ok=True)
    write_progress("starting")
    TOKENS.update()  # the (still empty) token log exists from the first second
    try:
        problems = load_problems()
    except Exception as error:
        fatal(f"{INPUT} is not a JSON file of the form {{\"problems\": [{{\"id\": ..., \"latex\": ...}}]}}: {error!r}")
    for problem in problems:
        write_atomic(OUT / f"{problem['id']}.tex", no_solution_tex(problem["id"]))
        set_status(problem["id"], stage="waiting")
    write_progress()
    if SUBMIT_POLICY not in ("verified", "certified", "always"):
        fatal(f"FP_SUBMIT_POLICY must be 'verified', 'certified' or 'always', not {SUBMIT_POLICY!r}")
    # docker's --env-file keeps quotation marks and stray spaces as part of the value
    os.environ["ANTHROPIC_API_KEY"] = os.environ.get("ANTHROPIC_API_KEY", "").strip().strip("\"'")
    if not os.environ["ANTHROPIC_API_KEY"]:
        fatal("ANTHROPIC_API_KEY is not set; it must be in the secrets file passed with --env-file")
    HEARTBEAT = threading.Thread(target=heartbeat, daemon=True)
    HEARTBEAT.start()
    print(f"{utc_now()} {len(problems)} problems; model {MODEL}; policy {SUBMIT_POLICY}", flush=True)
    note = None
    try:
        preflight()
    except Exception as error:  # a fault in the start-up test itself is no reason not to run
        print(f"{utc_now()} preflight failed: {type(error).__name__}: {error}", flush=True)
    try:
        # With more problems than MAX_PARALLEL they run in batches that share the solving time equally.
        batches = math.ceil(len(problems) / MAX_PARALLEL) or 1
        solve_seconds = (SOLVE_HOURS - elapsed_hours()) * 3600 / batches
        with ThreadPoolExecutor(MAX_PARALLEL) as pool:
            for problem in problems:
                pool.submit(work_on_safely, problem, solve_seconds)
        if STOP.is_set():
            note = "stopped by a signal before the end"
    except Exception as error:
        note = f"stopped by an error in the runner: {type(error).__name__}: {str(error)[:300]}"
        print(f"{utc_now()} {note}", flush=True)
    close_down(note)
    print(f"{utc_now()} done after {elapsed_hours():.2f} hours", flush=True)


if __name__ == "__main__":
    main()
