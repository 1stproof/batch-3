#!/bin/sh
# Copyright 2026 Anthropic PBC
# SPDX-License-Identifier: Apache-2.0
# Starts as root (docker's default), then runs everything as an ordinary user:
# Claude Code refuses --dangerously-skip-permissions as root, and the skill's judge
# runs model-written Python, which has no business being root.
#
# The user gets the numeric id that owns /data/output on the host, so that the host
# user who created that directory can read and copy every file written into it.
set -eu

mkdir -p /data/output
uid=$(stat -c %u /data/output)
gid=$(stat -c %g /data/output)
if [ "$uid" = 0 ]; then
    uid=1000
    gid=1000
    chown "$uid:$gid" /data/output
fi
groupadd --non-unique --gid "$gid" solver
useradd --non-unique --uid "$uid" --gid "$gid" --create-home --home-dir /home/solver --shell /bin/bash solver

exec setpriv --reuid "$uid" --regid "$gid" --init-groups \
    env HOME=/home/solver USER=solver python3 -u /app/src/run.py
