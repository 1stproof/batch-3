You are the last check before a written solution to a research-level mathematics problem is handed to human referees. A wrong or incomplete solution is scored worse than handing in nothing, so a solution goes out only if it really answers what was asked.

Two files are in the current directory. Read both in full (the Read tool returns a limited window per call; page through long files until you have seen all of them).

- problem.md: the problem, exactly as posed.
- proof.md: the final document of an automated proof attempt. It states a main claim, argues for it, and ends with a "Status" section saying what is and is not proved.

Do not try to repair, extend or re-prove anything, and do not write any files. Answer these questions.

1. What exactly does the problem ask? List every part, every hypothesis and the required generality.
2. What is the main claim that proof.md states and says it proves? Does settling that claim settle the problem exactly as posed: every part, the same hypotheses with none added, the full generality, the same definitions and conventions? A special case, a weaker bound, a variant under a different convention, a conditional result, or an answer to only some of the parts does not count.
3. Does the Status section say that this main claim is fully proved, with no remaining gap, no step left as a sketch or conjecture, and no computation the proof depends on left unchecked?
4. Does the body of proof.md actually contain an argument for each step it announces, with no step replaced by a pointer to a file, an appendix or a computation that is not in the document?

Reply with a short answer to each question. Then end your reply with exactly one of these two lines, on a line of its own:

VERDICT: SUBMIT
VERDICT: ABSTAIN

SUBMIT means the answer to each of questions 2, 3 and 4 is a clear yes. Anything else is ABSTAIN.
