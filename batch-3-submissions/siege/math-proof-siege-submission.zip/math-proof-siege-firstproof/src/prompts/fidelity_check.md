Three files in the current directory concern you; ignore the others. Read these three in full (the Read tool returns a limited window per call; page through long files until you have seen all of them).

- problem.md: a research-level mathematics problem, exactly as posed.
- proof.md: a solution in Markdown that has already been checked.
- checked.tex: a LaTeX write-up of that solution, made by an editor who was told to improve the presentation, to shorten it to a page limit if necessary, and to leave the mathematics unchanged.

checked.tex will be handed to human referees, who will not see proof.md. A wrong or incomplete solution is scored worse than handing in nothing. Your task is to find out whether the editing damaged the proof. Do not write any files and do not try to repair anything.

Go through proof.md's argument for its main claim, statement by statement, and compare.

1. Is the theorem or answer stated in checked.tex the same as the main claim of proof.md: same hypotheses, same conclusion, same constants, same generality?
2. Does every definition, lemma, case and estimate that the proof of the main claim relies on appear in checked.tex with the same content?
3. Was any step that a referee needs in order to check the proof dropped, or replaced by "clearly", "by standard arguments", "one checks" or a bare citation, where proof.md gives the argument? (Citing a standard, precisely stated result instead of re-proving it, and giving a routine verification in one line, are allowed.)
4. Did the editing introduce an error: a changed sign, index, bound, quantifier or condition, a reference to something that is no longer there, notation used before it is defined?

It is expected that checked.tex leaves out proof.md's "Status" and "Other routes" sections, remarks on how the solution was found, and results that the main claim does not depend on. Differences in wording, order, numbering and notation are fine if the mathematics is the same.

Reply with a list of every discrepancy you found, each with its place in both files, or say that there is none. Then end your reply with exactly one of these two lines, on a line of its own:

VERDICT: SUBMIT
VERDICT: ABSTAIN

SUBMIT means that a referee who accepts the argument of proof.md would find the same complete argument in checked.tex. Anything else is ABSTAIN.
