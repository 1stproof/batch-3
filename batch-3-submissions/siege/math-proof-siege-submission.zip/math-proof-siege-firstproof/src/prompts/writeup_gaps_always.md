
**Be plain about gaps.** proof.md may be incomplete. If its "Status" section says that something is not proved, or you find a step that does not hold, say so in a short paragraph headed "What is and is not proved" placed right after the result, and mark the gap at the place where it occurs. Never present an incomplete argument as complete.
