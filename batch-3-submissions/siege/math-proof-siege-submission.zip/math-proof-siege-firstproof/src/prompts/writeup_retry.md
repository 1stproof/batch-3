
**An earlier attempt failed a check.** If it left a solution.tex, start from that file and repair it instead of starting over. The check that failed:

{COMPLAINT}
