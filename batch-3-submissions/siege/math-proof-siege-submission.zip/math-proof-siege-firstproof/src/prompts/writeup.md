Two files are in the current directory.

- problem.md: a research-level mathematics problem, exactly as posed.
- proof.md: a solution in Markdown, produced and checked by an earlier automated process.

Your task is to typeset that solution as a LaTeX document, solution.tex, in the current directory. It will be read by expert human referees, under double-blind review, who give separate scores for correctness, exposition and attribution. Read both files in full first (the Read tool returns a limited window per call; page through long files until you have seen all of them). If a file solution.tex is already there, it is left over from an earlier attempt that did not finish or did not pass a check: treat it as a draft that may be incomplete.
{EARLIER}
**The mathematics stays as it is.** You are an editor, not a co-author. Keep the statements, the structure of the argument, the constants and the case distinctions of proof.md. Do not strengthen or weaken any claim, do not replace an argument by a different one, and do not drop a step that a referee needs in order to check the proof. Referees are hard on proofs that gloss over the most difficult step or say that a key claim follows "by standard arguments": where proof.md gives the details, keep them. You may correct obvious typos, unify notation, reorder for readability and add connecting sentences.
{GAPS}
**Contents, in this order.**
1. A plain title such as "Solution", with no author and no date.
2. The problem, restated faithfully from problem.md.
3. The result: the precise theorem proved, or the answer to the question asked.
4. A short overview of the idea of the proof, in prose, before the technical work starts.
5. The complete proof, organised into definitions, lemmas and propositions with their proofs.
6. References.
Leave out everything about how the solution was produced: proof.md's "Status" and "Other routes" sections, and any mention of attempts, rounds, checks, agents, files or tools.

**Anonymous.** Nothing in solution.tex, comments and PDF metadata included, may name or hint at an author, a company, a model, an AI system or a piece of software that produced it.

**Attribution.** State precisely every known result the proof uses, and credit it: who proved it, and where it can be found, as an entry in a thebibliography environment cited at the point of use. Give authors' first names as initials only. Say which parts are known and which are argued here. Do not use the network: every reference comes from memory. Give only the details you are confident of, never invent a title, a year, a theorem number or a page, and never cite a paper for a statement you are not confident it contains. If you are unsure of the source of a standard fact, say that it is standard, state it exactly, and if it is short include a proof.

**Format.** One self-contained file: \documentclass[11pt]{article}, one-inch margins (geometry), and only widely available packages such as amsmath, amssymb, amsthm, mathtools, enumitem, hyperref. No external files, images, .bib files or custom class files, nothing that needs shell escape, and plain pdfLaTeX only. It has to compile without errors on a stock TeX Live or Overleaf.

**Length.** At most {MAX_PAGES} pages when compiled, references included; stay a page below that if you can, since another TeX installation may break pages differently. If it runs longer, first tighten the prose, remove repetition, shorten routine calculations, and cite standard results precisely instead of re-proving them; never cut a step the proof depends on, and do not go below 10pt type or one-inch margins.

**Check your work.** Run `pdflatex -interaction=nonstopmode -halt-on-error solution.tex` at least twice, fix every error and every undefined reference, and read the number of pages from `pdfinfo solution.pdf`. Use the shell for nothing else. Then compare solution.tex with proof.md once more, statement by statement, and confirm that every claim, hypothesis and constant is unchanged and that no step was lost.

When solution.tex is finished, end your reply with this line, on a line of its own:

WRITEUP: DONE
